// Nama         : Gregorius Jovan Kresnadi
// NIM          : 13518135
// Tanggal      : 12-03-2020
// File 		: Expression.java

interface Expression {
	public int solve();
}
