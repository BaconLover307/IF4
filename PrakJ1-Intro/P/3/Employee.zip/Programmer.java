// Nama         : Gregorius Jovan Kresnadi
// NIM          : 13518135
// Tanggal      : 19-03-2020
// File 		: Programmer.java

// Buatlah sebuah kelas Employee dengan spesifikasi sebagai berikut:

//     Memiliki atribut bernama hasMarried bertipe boolean yang memiliki nilai default false
//     Memiliki sebuah default constructor.
//     Memiliki method public void setHasMarried(boolean hasMarried) yang mengubah
//          atribut hasMarried sesuai parameter.
//     Memiliki method public int calculateSalary(int workHour) untuk menghitung gaji
//          berdasarkan jam kerja yang diberikan. Method ini abstrak.

// Buatlah juga kelas Programmer yang merupakan turunan dari Employee,
//      yang mengoverride method int calculateSalary(int workHour) dengan aturan:
//     150 jam pertama, programmer mendapat gaji 100.000 per jam
//     Setelah 150 jam pertama, programmer mendapat gaji 10.000 per jam
//     Jika programmer sudah menikah, ia mendapat tambahan gaji 4.000.000

// Untuk lebih jelasnya, perhatikan tabel berikut: 

class Programmer extends Employee {
    public Programmer() {
        super();
    }

    public void setHasMarried(boolean hM) {
        this.hasMarried = hM;
    }

    public int calculateSalary(int workHour) {
        int gaji;
        if (workHour <= 150) {
            gaji = workHour*100000;
        } else {
            gaji = 150*100000 + (workHour-150) * 10000;
        }
        if (this.hasMarried) {
            gaji += 4000000;
        }
        return gaji;
    }

}