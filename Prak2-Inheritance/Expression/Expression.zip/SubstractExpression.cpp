/* Nama         : Gregorius Jovan Kresnadi */
/* NIM          : 13518135 */
/* Tanggal      : 13-02-2020 */

#include "SubtractExpression.hpp"
#include <iostream>

using namespace std;

SubstractExpression::SubstractExpression(TerminalExpression* x, TerminalExpression* y) {
    this->x = x;
    this->y = y;
}

void SubstractExpression::solve() {
	return this->x - this->y;
    
}