/* Nama         : Gregorius Jovan Kresnadi */
/* NIM          : 13518135 */
/* Tanggal      : 06-02-2020 */
/* Program      : RekeningGiro.hpp */
/* Deskripsi    : Implementasi RekeningGiro */

#include "RekeningGiro.h"
#include <iostream>

using namespace std;

RekeningGiro::RekeningGiro(double saldo, double sb) : Rekening(saldo) {
	if (sb < 0) this->sb = 0.0;
	else this->sb = sb;
}

void RekeningGiro::setSukuBunga(double sb) {
	if (sb < 0) this->sb = 0.0;
	else this->sb = sb;
}

double RekeningGiro::getSukuBunga() const{
	return this->sb;
}

double RekeningGiro::hitungBunga() {
	return saldo * sb;
}
