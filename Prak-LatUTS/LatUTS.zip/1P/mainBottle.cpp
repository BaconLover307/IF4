/* Nama         : Gregorius Jovan Kresnadi */
/* NIM          : 13518135 */
/* Tanggal      : 30-01-2020 */
/* Program      : main.cpp */
/* Deskripsi    : Main untuk Bottle.cpp */

#include "Bottle.hpp"
#include <iostream>

using namespace std;

int main() {
	Bottle A;

	return 0;
}
