#include "A.hpp"
#include <iostream>

using namespace std;

A::A() {
    cout << "Boom A!" << endl;
}

void A::sing() {
    cout << "Do A Do A Do A..." << endl;
}