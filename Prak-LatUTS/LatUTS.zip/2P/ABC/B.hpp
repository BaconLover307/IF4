#ifndef _B_HPP_
#define _B_HPP_

class B {
public:
    B();
    void sing();
};

#endif
