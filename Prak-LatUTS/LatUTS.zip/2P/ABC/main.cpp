#include "C.hpp"
#include <bits/stdc++.h>

using namespace std;

int main() {
    C c;
    c.sing();
}