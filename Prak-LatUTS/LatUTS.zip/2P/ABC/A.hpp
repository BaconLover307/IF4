#ifndef _A_HPP_
#define _A_HPP_

class A {
public:
    A();
    void sing();
};

#endif
