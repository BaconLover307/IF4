/* Nama         : Gregorius Jovan Kresnadi */
/* NIM          : 13518135 */
/* Tanggal      : 13-02-2020 */

#include <iostream>
#include "AddExpression.hpp"
#include "SubstractExpression.hpp"
#include "NegativeExpression.hpp"
#include "Expression.hpp"

using namespace std;

int main() {
	TerminalExpression t(1);

  return 0;
}