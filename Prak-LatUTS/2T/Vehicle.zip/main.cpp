// Nama : Gregorius Jovan Kresnadi
// NIM  : 13518135
// Latihan UTS OOP

#include "Car.h"
#include "Bike.h"
#include <bits/stdc++.h>

int main() {
    Vehicle va(3,2);
    Vehicle vb=va;
    Vehicle vc(6,50);
    Car ca(8);
    Car cb = ca;
    Car cc(6);
    Bike ba;
    cc.drive();
    ba.show();
    ba.ride();
    
    return 0;
}