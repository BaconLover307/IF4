// Nama         : Gregorius Jovan Kresnadi
// NIM          : 13518135
// Tanggal      : 28-04-2020
// Topic 		: Interface

// Abstract Base Class berikut tidak memiliki method yang
// terdefinisikan. Karena itu, kelas ini perlu dikonversi
// menjadi interface di java.
interface Expression {
    public int solve();
}
